#!/bin/bash

echo "🚀 Starting Million Dollar Crypto Homepage..."

# Start backend server
cd /home/claude/crypto-pixel-homepage/backend
node server.js &
BACKEND_PID=$!

echo "✅ Backend server running on http://localhost:3001"
echo "📊 Admin panel: http://localhost:3001/admin"
echo "   Default login: admin / admin123"
echo ""
echo "Press Ctrl+C to stop the server"

# Wait for the backend process
wait $BACKEND_PID
