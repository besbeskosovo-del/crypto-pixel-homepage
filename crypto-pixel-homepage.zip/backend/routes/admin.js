const express = require('express');
const { verifyToken, generateToken } = require('../middleware/auth');
const { orderOps, pixelOps, adminOps, walletOps, settingsOps } = require('../models/database');

const router = express.Router();

// Admin login
router.post('/login', (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ error: 'Username and password required' });
    }

    const user = adminOps.authenticate(username, password);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken(user);
    res.json({ token, user: { id: user.id, username: user.username } });
  } catch (err) {
    res.status(500).json({ error: 'Login failed' });
  }
});

// Protected routes below
router.use(verifyToken);

// Get current user
router.get('/me', (req, res) => {
  res.json({ user: req.user });
});

// Change password
router.post('/change-password', (req, res) => {
  try {
    const { newPassword } = req.body;
    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    adminOps.changePassword(req.user.id, newPassword);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to change password' });
  }
});

// Get dashboard stats
router.get('/stats', (req, res) => {
  try {
    const stats = orderOps.getStats();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Get all orders with filtering
router.get('/orders', (req, res) => {
  try {
    const { status, limit = 50, offset = 0 } = req.query;
    const orders = orderOps.getAll(status || null, parseInt(limit), parseInt(offset));
    res.json({ orders });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// Get single order
router.get('/orders/:id', (req, res) => {
  try {
    const order = orderOps.getById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json({ order });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch order' });
  }
});

// Update order status
router.patch('/orders/:id', (req, res) => {
  try {
    const { status, txHash, notes } = req.body;
    const order = orderOps.getById(req.params.id);

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const validStatuses = ['pending', 'confirmed', 'cancelled', 'refunded'];
    if (status && !validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    // If cancelling or refunding, release the pixels
    if ((status === 'cancelled' || status === 'refunded') && order.status !== status) {
      pixelOps.releasePixels(order.id);
    }

    orderOps.updateStatus(req.params.id, status, txHash, notes);
    
    const updatedOrder = orderOps.getById(req.params.id);
    res.json({ success: true, order: updatedOrder });
  } catch (err) {
    console.error('Order update error:', err);
    res.status(500).json({ error: 'Failed to update order' });
  }
});

// Delete order (admin only)
router.delete('/orders/:id', (req, res) => {
  try {
    const order = orderOps.getById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    // Release pixels
    pixelOps.releasePixels(order.id);

    // Delete order
    const { db } = require('../models/database');
    db.prepare('DELETE FROM orders WHERE id = ?').run(req.params.id);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete order' });
  }
});

// Get wallet addresses
router.get('/wallets', (req, res) => {
  try {
    const wallets = walletOps.getAll();
    res.json({ wallets });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch wallets' });
  }
});

// Update wallet address
router.patch('/wallets/:currency', (req, res) => {
  try {
    const { address, network } = req.body;
    const currency = req.params.currency.toUpperCase();

    if (!address) {
      return res.status(400).json({ error: 'Address is required' });
    }

    walletOps.update(currency, address, network || null);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update wallet' });
  }
});

// Get settings
router.get('/settings', (req, res) => {
  try {
    const settings = settingsOps.getAll();
    res.json({ settings });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

// Update settings
router.patch('/settings', (req, res) => {
  try {
    const allowedKeys = ['site_name', 'min_pixels', 'max_pixels', 'price_per_pixel'];
    
    for (const [key, value] of Object.entries(req.body)) {
      if (allowedKeys.includes(key)) {
        settingsOps.set(key, String(value));
      }
    }

    const settings = settingsOps.getAll();
    res.json({ success: true, settings });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

module.exports = router;
