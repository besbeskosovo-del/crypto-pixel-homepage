const express = require('express');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs');
const { pixelOps, orderOps, walletOps, settingsOps } = require('../models/database');

const router = express.Router();

// Configure multer for image uploads
const storage = multer.memoryStorage();
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only JPEG, PNG, GIF, and WebP are allowed.'));
    }
  }
});

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Get all sold pixels (for rendering the grid)
router.get('/pixels', (req, res) => {
  try {
    const pixels = pixelOps.getSoldPixels();
    res.json({ pixels });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch pixels' });
  }
});

// Check pixel availability
router.post('/pixels/check', (req, res) => {
  try {
    const { startX, startY, width, height } = req.body;

    // Validate input
    if (startX < 0 || startY < 0 || startX + width > 1000 || startY + height > 1000) {
      return res.status(400).json({ error: 'Selection out of bounds' });
    }

    const settings = settingsOps.getAll();
    const pixelCount = width * height;

    if (pixelCount < parseInt(settings.min_pixels)) {
      return res.status(400).json({ error: `Minimum purchase is ${settings.min_pixels} pixels` });
    }

    if (pixelCount > parseInt(settings.max_pixels)) {
      return res.status(400).json({ error: `Maximum purchase is ${settings.max_pixels} pixels` });
    }

    const available = pixelOps.checkAvailability(startX, startY, width, height);
    res.json({ available, pixelCount, amount: pixelCount * parseFloat(settings.price_per_pixel) });
  } catch (err) {
    res.status(500).json({ error: 'Failed to check availability' });
  }
});

// Get wallet addresses
router.get('/wallets', (req, res) => {
  try {
    const wallets = walletOps.getAll().filter(w => w.is_active);
    res.json({ wallets });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch wallets' });
  }
});

// Get site settings (public)
router.get('/settings', (req, res) => {
  try {
    const settings = settingsOps.getAll();
    res.json({
      siteName: settings.site_name,
      minPixels: parseInt(settings.min_pixels),
      maxPixels: parseInt(settings.max_pixels),
      pricePerPixel: parseFloat(settings.price_per_pixel)
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch settings' });
  }
});

// Get stats (public)
router.get('/stats', (req, res) => {
  try {
    const stats = orderOps.getStats();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Create a new order
router.post('/orders', upload.single('image'), async (req, res) => {
  try {
    const { email, websiteUrl, startX, startY, width, height, cryptoCurrency } = req.body;

    // Validate required fields
    if (!email || !startX || !startY || !width || !height || !cryptoCurrency) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const x = parseInt(startX);
    const y = parseInt(startY);
    const w = parseInt(width);
    const h = parseInt(height);

    // Validate bounds
    if (x < 0 || y < 0 || x + w > 1000 || y + h > 1000) {
      return res.status(400).json({ error: 'Selection out of bounds' });
    }

    const settings = settingsOps.getAll();
    const pixelCount = w * h;

    if (pixelCount < parseInt(settings.min_pixels)) {
      return res.status(400).json({ error: `Minimum purchase is ${settings.min_pixels} pixels` });
    }

    if (pixelCount > parseInt(settings.max_pixels)) {
      return res.status(400).json({ error: `Maximum purchase is ${settings.max_pixels} pixels` });
    }

    // Check availability
    const available = pixelOps.checkAvailability(x, y, w, h);
    if (!available) {
      return res.status(400).json({ error: 'Some pixels in this area are already sold' });
    }

    // Get wallet address for selected cryptocurrency
    const wallet = walletOps.getByCurrency(cryptoCurrency.toUpperCase());
    if (!wallet) {
      return res.status(400).json({ error: 'Invalid cryptocurrency selected' });
    }

    // Process image if uploaded
    let imageUrl = null;
    if (req.file) {
      const orderId = uuidv4();
      const filename = `${orderId}.png`;
      const filepath = path.join(uploadsDir, filename);

      // Resize image to match pixel dimensions
      await sharp(req.file.buffer)
        .resize(w, h, { fit: 'fill' })
        .png()
        .toFile(filepath);

      imageUrl = `/uploads/${filename}`;
    }

    const orderId = uuidv4();
    const amountUsd = pixelCount * parseFloat(settings.price_per_pixel);

    // Create order
    const order = {
      id: orderId,
      email,
      websiteUrl: websiteUrl || null,
      imageUrl,
      startX: x,
      startY: y,
      width: w,
      height: h,
      pixelCount,
      amountUsd,
      cryptoCurrency: cryptoCurrency.toUpperCase(),
      cryptoAmount: null, // Will be set when we integrate price feeds
      walletAddress: wallet.address
    };

    orderOps.create(order);

    // Reserve pixels
    pixelOps.reservePixels(x, y, w, h, orderId);

    res.json({
      success: true,
      order: {
        id: orderId,
        amountUsd,
        cryptoCurrency: order.cryptoCurrency,
        walletAddress: wallet.address,
        network: wallet.network,
        pixelCount,
        startX: x,
        startY: y,
        width: w,
        height: h
      }
    });
  } catch (err) {
    console.error('Order creation error:', err);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

// Get order status
router.get('/orders/:id', (req, res) => {
  try {
    const order = orderOps.getById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json({ order });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch order' });
  }
});

// Upload image for existing order
router.post('/orders/:id/image', upload.single('image'), async (req, res) => {
  try {
    const order = orderOps.getById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    if (!req.file) {
      return res.status(400).json({ error: 'No image provided' });
    }

    const filename = `${order.id}.png`;
    const filepath = path.join(uploadsDir, filename);

    // Resize image to match pixel dimensions
    await sharp(req.file.buffer)
      .resize(order.width, order.height, { fit: 'fill' })
      .png()
      .toFile(filepath);

    // Update order with image URL
    const { db } = require('../models/database');
    db.prepare('UPDATE orders SET image_url = ? WHERE id = ?').run(`/uploads/${filename}`, order.id);

    res.json({ success: true, imageUrl: `/uploads/${filename}` });
  } catch (err) {
    console.error('Image upload error:', err);
    res.status(500).json({ error: 'Failed to upload image' });
  }
});

module.exports = router;
