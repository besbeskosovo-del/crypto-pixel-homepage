const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, '..', 'database.sqlite');

let db = null;
let SQL = null;

async function getDB() {
  if (db) return db;
  
  SQL = await initSqlJs();
  
  // Load existing database if exists
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }
  
  return db;
}

function saveDB() {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Initialize database tables
async function initDatabase() {
  const database = await getDB();
  
  // Pixels table
  database.run(`
    CREATE TABLE IF NOT EXISTS pixels (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      x INTEGER NOT NULL,
      y INTEGER NOT NULL,
      order_id TEXT NOT NULL,
      UNIQUE(x, y)
    )
  `);

  // Orders table
  database.run(`
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      email TEXT NOT NULL,
      website_url TEXT,
      image_url TEXT,
      start_x INTEGER NOT NULL,
      start_y INTEGER NOT NULL,
      width INTEGER NOT NULL,
      height INTEGER NOT NULL,
      pixel_count INTEGER NOT NULL,
      amount_usd REAL NOT NULL,
      crypto_currency TEXT NOT NULL,
      crypto_amount TEXT,
      wallet_address TEXT NOT NULL,
      tx_hash TEXT,
      status TEXT DEFAULT 'pending',
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      confirmed_at TEXT,
      notes TEXT
    )
  `);

  // Admin users table
  database.run(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT DEFAULT (datetime('now'))
    )
  `);

  // Wallet addresses table
  database.run(`
    CREATE TABLE IF NOT EXISTS wallets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      currency TEXT UNIQUE NOT NULL,
      address TEXT NOT NULL,
      network TEXT,
      is_active INTEGER DEFAULT 1
    )
  `);

  // Site settings table
  database.run(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    )
  `);

  // Create default admin if not exists
  const adminExists = database.exec("SELECT id FROM admin_users WHERE username = 'admin'");
  if (adminExists.length === 0 || adminExists[0].values.length === 0) {
    const hash = bcrypt.hashSync('admin123', 10);
    database.run('INSERT OR IGNORE INTO admin_users (username, password_hash) VALUES (?, ?)', ['admin', hash]);
    console.log('Default admin created - username: admin, password: admin123');
  }

  // Create default wallet addresses
  const wallets = [
    { currency: 'BTC', address: 'YOUR_BTC_ADDRESS_HERE', network: 'Bitcoin' },
    { currency: 'ETH', address: 'YOUR_ETH_ADDRESS_HERE', network: 'Ethereum' },
    { currency: 'USDT', address: 'YOUR_USDT_ADDRESS_HERE', network: 'ERC-20' },
    { currency: 'USDC', address: 'YOUR_USDC_ADDRESS_HERE', network: 'ERC-20' }
  ];

  wallets.forEach(w => {
    database.run('INSERT OR IGNORE INTO wallets (currency, address, network) VALUES (?, ?, ?)', 
      [w.currency, w.address, w.network]);
  });

  // Default settings
  const defaultSettings = [
    { key: 'site_name', value: 'Million Dollar Crypto Homepage' },
    { key: 'min_pixels', value: '100' },
    { key: 'max_pixels', value: '50000' },
    { key: 'price_per_pixel', value: '1' }
  ];

  defaultSettings.forEach(s => {
    database.run('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', [s.key, s.value]);
  });

  saveDB();
  console.log('Database initialized successfully');
}

// Helper to get results
function getOne(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    if (stmt.step()) {
      const row = stmt.getAsObject();
      stmt.free();
      return row;
    }
    stmt.free();
    return null;
  } catch (err) {
    console.error('Query error:', err);
    return null;
  }
}

function getAll(sql, params = []) {
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    const results = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject());
    }
    stmt.free();
    return results;
  } catch (err) {
    console.error('Query error:', err);
    return [];
  }
}

// Pixel operations
const pixelOps = {
  getAll: () => getAll('SELECT x, y, order_id FROM pixels'),

  getSoldPixels: () => getAll(`
    SELECT p.x, p.y, p.order_id, o.image_url, o.website_url, o.email
    FROM pixels p
    JOIN orders o ON p.order_id = o.id
    WHERE o.status = 'confirmed'
  `),

  checkAvailability: (startX, startY, width, height) => {
    const pixels = getAll(
      'SELECT x, y FROM pixels WHERE x >= ? AND x < ? AND y >= ? AND y < ?',
      [startX, startX + width, startY, startY + height]
    );
    return pixels.length === 0;
  },

  reservePixels: (startX, startY, width, height, orderId) => {
    for (let x = startX; x < startX + width; x++) {
      for (let y = startY; y < startY + height; y++) {
        db.run('INSERT INTO pixels (x, y, order_id) VALUES (?, ?, ?)', [x, y, orderId]);
      }
    }
    saveDB();
  },

  releasePixels: (orderId) => {
    db.run('DELETE FROM pixels WHERE order_id = ?', [orderId]);
    saveDB();
  }
};

// Order operations
const orderOps = {
  create: (order) => {
    db.run(`
      INSERT INTO orders (id, email, website_url, image_url, start_x, start_y, width, height, 
        pixel_count, amount_usd, crypto_currency, crypto_amount, wallet_address, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      order.id, order.email, order.websiteUrl, order.imageUrl,
      order.startX, order.startY, order.width, order.height,
      order.pixelCount, order.amountUsd, order.cryptoCurrency,
      order.cryptoAmount, order.walletAddress, 'pending'
    ]);
    saveDB();
    return order;
  },

  getById: (id) => getOne('SELECT * FROM orders WHERE id = ?', [id]),

  getAll: (status = null, limit = 100, offset = 0) => {
    if (status) {
      return getAll(
        'SELECT * FROM orders WHERE status = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
        [status, limit, offset]
      );
    }
    return getAll(
      'SELECT * FROM orders ORDER BY created_at DESC LIMIT ? OFFSET ?',
      [limit, offset]
    );
  },

  updateStatus: (id, status, txHash = null, notes = null) => {
    let sql = 'UPDATE orders SET status = ?, updated_at = datetime("now")';
    const params = [status];

    if (txHash) {
      sql += ', tx_hash = ?';
      params.push(txHash);
    }
    if (notes) {
      sql += ', notes = ?';
      params.push(notes);
    }
    if (status === 'confirmed') {
      sql += ', confirmed_at = datetime("now")';
    }

    sql += ' WHERE id = ?';
    params.push(id);
    db.run(sql, params);
    saveDB();
  },

  getStats: () => {
    const totalOrders = getOne('SELECT COUNT(*) as count FROM orders');
    const confirmedOrders = getOne("SELECT COUNT(*) as count FROM orders WHERE status = 'confirmed'");
    const pendingOrders = getOne("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'");
    const totalRevenue = getOne("SELECT SUM(amount_usd) as total FROM orders WHERE status = 'confirmed'");
    const totalPixelsSold = getOne("SELECT SUM(pixel_count) as total FROM orders WHERE status = 'confirmed'");

    return {
      totalOrders: totalOrders?.count || 0,
      confirmedOrders: confirmedOrders?.count || 0,
      pendingOrders: pendingOrders?.count || 0,
      totalRevenue: totalRevenue?.total || 0,
      totalPixelsSold: totalPixelsSold?.total || 0,
      availablePixels: 1000000 - (totalPixelsSold?.total || 0)
    };
  }
};

// Admin operations
const adminOps = {
  authenticate: (username, password) => {
    const user = getOne('SELECT * FROM admin_users WHERE username = ?', [username]);
    if (user && bcrypt.compareSync(password, user.password_hash)) {
      return { id: user.id, username: user.username };
    }
    return null;
  },

  changePassword: (userId, newPassword) => {
    const hash = bcrypt.hashSync(newPassword, 10);
    db.run('UPDATE admin_users SET password_hash = ? WHERE id = ?', [hash, userId]);
    saveDB();
  }
};

// Wallet operations
const walletOps = {
  getAll: () => getAll('SELECT * FROM wallets'),

  getByCurrency: (currency) => getOne('SELECT * FROM wallets WHERE currency = ? AND is_active = 1', [currency]),

  update: (currency, address, network) => {
    db.run('UPDATE wallets SET address = ?, network = ? WHERE currency = ?', [address, network, currency]);
    saveDB();
  }
};

// Settings operations
const settingsOps = {
  get: (key) => {
    const row = getOne('SELECT value FROM settings WHERE key = ?', [key]);
    return row ? row.value : null;
  },

  set: (key, value) => {
    db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, value]);
    saveDB();
  },

  getAll: () => {
    const rows = getAll('SELECT * FROM settings');
    return rows.reduce((acc, row) => {
      acc[row.key] = row.value;
      return acc;
    }, {});
  }
};

module.exports = {
  getDB,
  initDatabase,
  pixelOps,
  orderOps,
  adminOps,
  walletOps,
  settingsOps
};
