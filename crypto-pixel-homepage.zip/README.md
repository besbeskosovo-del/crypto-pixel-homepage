# 💰 Million Dollar Crypto Homepage

A modern recreation of the iconic Million Dollar Homepage, built for the crypto community. Each pixel costs $1, payable in BTC, ETH, USDT, or USDC.

![Preview](https://via.placeholder.com/800x400/f09332/ffffff?text=Million+Dollar+Crypto+Homepage)

## Features

### 🎨 Interactive Pixel Grid
- 1000×1000 pixel canvas (1 million pixels total)
- Zoom and pan navigation
- Real-time pixel selection
- Visual display of sold vs available pixels

### 💳 Crypto Payments
- **Bitcoin (BTC)**
- **Ethereum (ETH)**
- **Tether (USDT)** - ERC-20
- **USD Coin (USDC)** - ERC-20

### 📊 Admin Dashboard
- Order management (approve/cancel/refund)
- Revenue statistics
- Wallet address configuration
- Real-time stats

### 🌓 Modern UI
- Light/Dark theme support
- Responsive design
- Beautiful animations
- QR codes for easy payment

## Tech Stack

- **Frontend**: React 18, Vite, Tailwind CSS
- **Backend**: Node.js, Express
- **Database**: SQLite (sql.js)
- **Payments**: Manual wallet verification (extensible to payment processors)

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. **Install backend dependencies:**
   ```bash
   cd backend
   npm install
   ```

2. **Install frontend dependencies:**
   ```bash
   cd frontend
   npm install
   ```

3. **Build frontend:**
   ```bash
   cd frontend
   npm run build
   ```

4. **Start the server:**
   ```bash
   cd backend
   npm start
   ```

Or simply run:
```bash
chmod +x start.sh
./start.sh
```

### Access

- **Website**: http://localhost:3001
- **Admin Panel**: http://localhost:3001/admin
- **API**: http://localhost:3001/api

### Default Admin Credentials

```
Username: admin
Password: admin123
```

⚠️ **IMPORTANT**: Change the admin password after first login!

## Configuration

### Setting Up Wallet Addresses

1. Login to the admin panel at `/admin`
2. Go to the "Wallets" tab
3. Update each cryptocurrency address with your own wallet addresses
4. Click "Save Changes"

### Environment Variables

Create a `.env` file in the `backend` directory:

```env
PORT=3001
JWT_SECRET=your-super-secret-jwt-key-change-in-production
```

## API Endpoints

### Public Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/pixels` | Get all sold pixels |
| POST | `/api/pixels/check` | Check pixel availability |
| GET | `/api/wallets` | Get wallet addresses |
| GET | `/api/settings` | Get site settings |
| GET | `/api/stats` | Get public stats |
| POST | `/api/orders` | Create new order |
| GET | `/api/orders/:id` | Get order by ID |

### Admin Endpoints (Requires Auth)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/admin/login` | Admin login |
| GET | `/api/admin/stats` | Get detailed stats |
| GET | `/api/admin/orders` | List all orders |
| PATCH | `/api/admin/orders/:id` | Update order status |
| DELETE | `/api/admin/orders/:id` | Delete order |
| GET | `/api/admin/wallets` | Get all wallets |
| PATCH | `/api/admin/wallets/:currency` | Update wallet |

## Purchase Flow

1. **Select Pixels**: User clicks and drags on the grid to select pixels
2. **Enter Details**: Email, website URL, and image upload
3. **Choose Payment**: Select BTC, ETH, USDT, or USDC
4. **Complete Payment**: Send exact amount to displayed wallet address
5. **Confirmation**: Admin verifies payment and confirms order
6. **Go Live**: Pixels appear on the grid with user's image

## Order Status

| Status | Description |
|--------|-------------|
| `pending` | Awaiting payment |
| `confirmed` | Payment verified, pixels live |
| `cancelled` | Order cancelled, pixels released |
| `refunded` | Payment refunded, pixels released |

## Customization

### Minimum/Maximum Pixels

Edit settings in admin panel or directly in database:
- `min_pixels`: Minimum purchase (default: 100)
- `max_pixels`: Maximum purchase (default: 50,000)
- `price_per_pixel`: Price per pixel (default: $1)

### Styling

Edit `frontend/src/index.css` and `frontend/tailwind.config.js` to customize:
- Colors
- Fonts
- Animations
- Component styles

## Production Deployment

### Security Checklist

- [ ] Change default admin password
- [ ] Set strong `JWT_SECRET`
- [ ] Configure HTTPS/SSL
- [ ] Set up proper wallet addresses
- [ ] Enable rate limiting
- [ ] Configure CORS for your domain

### Recommended Setup

1. Use a process manager like PM2:
   ```bash
   npm install -g pm2
   pm2 start backend/server.js --name crypto-pixel
   ```

2. Set up Nginx reverse proxy with SSL

3. Use a proper database like PostgreSQL for production

## Extending Payment Processing

The current implementation uses manual wallet verification. To integrate automatic payment processors:

### Coinbase Commerce
```javascript
// Example integration point in backend/routes/api.js
const coinbase = require('coinbase-commerce-node');
// ... webhook handling for payment confirmation
```

### BTCPay Server
```javascript
// Self-hosted Bitcoin payment processing
// ... BTCPay integration
```

## Support

For issues and feature requests, please open an issue on GitHub.

## License

MIT License - feel free to use and modify for your own projects.

---

Built with ❤️ for the crypto community
