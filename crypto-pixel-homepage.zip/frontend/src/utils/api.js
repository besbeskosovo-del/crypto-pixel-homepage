const API_BASE = '/api';

export async function fetchPixels() {
  const response = await fetch(`${API_BASE}/pixels`);
  if (!response.ok) throw new Error('Failed to fetch pixels');
  return response.json();
}

export async function checkAvailability(startX, startY, width, height) {
  const response = await fetch(`${API_BASE}/pixels/check`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ startX, startY, width, height })
  });
  return response.json();
}

export async function fetchWallets() {
  const response = await fetch(`${API_BASE}/wallets`);
  if (!response.ok) throw new Error('Failed to fetch wallets');
  return response.json();
}

export async function fetchSettings() {
  const response = await fetch(`${API_BASE}/settings`);
  if (!response.ok) throw new Error('Failed to fetch settings');
  return response.json();
}

export async function fetchStats() {
  const response = await fetch(`${API_BASE}/stats`);
  if (!response.ok) throw new Error('Failed to fetch stats');
  return response.json();
}

export async function createOrder(formData) {
  const response = await fetch(`${API_BASE}/orders`, {
    method: 'POST',
    body: formData
  });
  return response.json();
}

export async function fetchOrder(orderId) {
  const response = await fetch(`${API_BASE}/orders/${orderId}`);
  if (!response.ok) throw new Error('Failed to fetch order');
  return response.json();
}

export async function uploadOrderImage(orderId, imageFile) {
  const formData = new FormData();
  formData.append('image', imageFile);
  
  const response = await fetch(`${API_BASE}/orders/${orderId}/image`, {
    method: 'POST',
    body: formData
  });
  return response.json();
}

export function formatCurrency(amount) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function formatNumber(num) {
  return new Intl.NumberFormat('en-US').format(num);
}

export function getCryptoIcon(currency) {
  const icons = {
    BTC: '₿',
    ETH: 'Ξ',
    USDT: '₮',
    USDC: '$'
  };
  return icons[currency] || '$';
}

export function getCryptoColor(currency) {
  const colors = {
    BTC: '#f7931a',
    ETH: '#627eea',
    USDT: '#26a17b',
    USDC: '#2775ca'
  };
  return colors[currency] || '#888';
}
