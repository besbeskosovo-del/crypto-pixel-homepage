import { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { formatCurrency, getCryptoColor } from '../utils/api';

export default function PaymentModal({ order, onClose }) {
  const [copied, setCopied] = useState(false);

  if (!order) return null;

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(order.walletAddress);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const getQRValue = () => {
    const currency = order.cryptoCurrency;
    const address = order.walletAddress;
    const amount = order.amountUsd;

    switch (currency) {
      case 'BTC':
        return `bitcoin:${address}?amount=${amount}`;
      case 'ETH':
        return `ethereum:${address}?value=${amount}`;
      default:
        return address;
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content p-6" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-display font-bold">Complete Payment</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Order Summary */}
        <div className="bg-stone-50 dark:bg-stone-800 rounded-xl p-4 mb-6">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-stone-500">Order ID</span>
              <p className="font-mono text-xs mt-1 break-all">{order.id}</p>
            </div>
            <div>
              <span className="text-stone-500">Pixels</span>
              <p className="font-bold mt-1">{order.pixelCount.toLocaleString()}</p>
            </div>
            <div>
              <span className="text-stone-500">Position</span>
              <p className="font-mono mt-1">({order.startX}, {order.startY})</p>
            </div>
            <div>
              <span className="text-stone-500">Size</span>
              <p className="font-mono mt-1">{order.width} × {order.height}</p>
            </div>
          </div>
        </div>

        {/* Amount */}
        <div className="text-center mb-6">
          <p className="text-stone-500 text-sm">Amount to Pay</p>
          <p className="text-4xl font-display font-bold text-primary-600 dark:text-primary-400">
            {formatCurrency(order.amountUsd)}
          </p>
          <p className="text-sm text-stone-500 mt-1">
            in {order.cryptoCurrency}
          </p>
        </div>

        {/* QR Code */}
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-white rounded-xl shadow-inner">
            <QRCodeSVG 
              value={getQRValue()} 
              size={180}
              level="H"
              fgColor={getCryptoColor(order.cryptoCurrency)}
            />
          </div>
        </div>

        {/* Wallet Address */}
        <div className="mb-6">
          <label className="block text-sm text-stone-500 mb-2">
            Send {order.cryptoCurrency} to this address ({order.network})
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              readOnly
              value={order.walletAddress}
              className="input-field font-mono text-sm flex-1"
            />
            <button
              onClick={copyAddress}
              className={`px-4 py-2 rounded-xl font-medium transition-all ${
                copied 
                  ? 'bg-emerald-500 text-white' 
                  : 'bg-stone-200 dark:bg-stone-700 hover:bg-stone-300 dark:hover:bg-stone-600'
              }`}
            >
              {copied ? '✓ Copied' : 'Copy'}
            </button>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4 mb-6">
          <h4 className="font-semibold text-amber-800 dark:text-amber-200 mb-2 flex items-center gap-2">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            Important
          </h4>
          <ul className="text-sm text-amber-700 dark:text-amber-300 space-y-1">
            <li>• Send the exact amount shown above</li>
            <li>• Your pixels will be activated after payment confirmation</li>
            <li>• Save your Order ID for tracking</li>
            <li>• Payment typically confirms within 10-60 minutes</li>
          </ul>
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <button onClick={onClose} className="btn-secondary flex-1">
            Close
          </button>
          <a 
            href={`/order/${order.id}`}
            className="btn-primary flex-1 text-center"
          >
            Track Order
          </a>
        </div>
      </div>
    </div>
  );
}
