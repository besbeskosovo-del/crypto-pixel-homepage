import { getCryptoIcon, getCryptoColor } from '../utils/api';

const cryptoData = {
  BTC: { name: 'Bitcoin', icon: '₿', color: '#f7931a', class: 'btc' },
  ETH: { name: 'Ethereum', icon: 'Ξ', color: '#627eea', class: 'eth' },
  USDT: { name: 'Tether', icon: '₮', color: '#26a17b', class: 'usdt' },
  USDC: { name: 'USD Coin', icon: '$', color: '#2775ca', class: 'usdc' }
};

export default function CryptoSelector({ wallets = [], selected, onSelect }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      {wallets.map(wallet => {
        const crypto = cryptoData[wallet.currency] || {};
        const isSelected = selected === wallet.currency;
        
        return (
          <button
            key={wallet.currency}
            onClick={() => onSelect(wallet.currency)}
            className={`crypto-card ${crypto.class} ${isSelected ? 'selected' : ''}`}
          >
            <div className="flex items-center gap-3">
              <div 
                className="w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg"
                style={{ backgroundColor: crypto.color }}
              >
                {crypto.icon}
              </div>
              <div className="text-left">
                <div className="font-bold text-stone-900 dark:text-white">{wallet.currency}</div>
                <div className="text-xs text-stone-500 dark:text-stone-400">{crypto.name}</div>
                {wallet.network && (
                  <div className="text-xs text-stone-400 dark:text-stone-500">{wallet.network}</div>
                )}
              </div>
            </div>
            {isSelected && (
              <div className="absolute top-2 right-2">
                <svg className="w-6 h-6 text-primary-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              </div>
            )}
          </button>
        );
      })}
    </div>
  );
}
