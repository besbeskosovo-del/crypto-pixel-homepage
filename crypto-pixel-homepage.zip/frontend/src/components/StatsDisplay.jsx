import { formatCurrency, formatNumber } from '../utils/api';

export default function StatsDisplay({ stats }) {
  if (!stats) return null;

  const statItems = [
    {
      label: 'Pixels Sold',
      value: formatNumber(stats.totalPixelsSold || 0),
      subtext: `of 1,000,000`
    },
    {
      label: 'Revenue',
      value: formatCurrency(stats.totalRevenue || 0),
      subtext: 'total raised'
    },
    {
      label: 'Available',
      value: formatNumber(stats.availablePixels || 1000000),
      subtext: 'pixels left'
    },
    {
      label: 'Orders',
      value: formatNumber(stats.confirmedOrders || 0),
      subtext: 'confirmed'
    }
  ];

  const soldPercentage = ((stats.totalPixelsSold || 0) / 1000000) * 100;

  return (
    <div className="space-y-6">
      {/* Progress bar */}
      <div>
        <div className="flex justify-between text-sm mb-2">
          <span className="text-stone-500">Progress to $1,000,000</span>
          <span className="font-mono font-bold text-primary-600 dark:text-primary-400">
            {soldPercentage.toFixed(2)}%
          </span>
        </div>
        <div className="h-4 bg-stone-200 dark:bg-stone-800 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-primary-400 to-primary-600 rounded-full transition-all duration-1000"
            style={{ width: `${Math.min(100, soldPercentage)}%` }}
          />
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statItems.map((stat, index) => (
          <div key={index} className="stat-card">
            <div className="stat-value">{stat.value}</div>
            <div className="stat-label">{stat.label}</div>
            <div className="text-xs text-stone-400 mt-0.5">{stat.subtext}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
