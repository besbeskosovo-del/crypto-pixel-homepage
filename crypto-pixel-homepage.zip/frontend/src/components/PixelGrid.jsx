import { useRef, useEffect, useState, useCallback } from 'react';

const GRID_SIZE = 1000;
const MIN_ZOOM = 0.3;
const MAX_ZOOM = 10;

export default function PixelGrid({ 
  pixels = [], 
  onSelect, 
  selection, 
  isSelecting = false,
  readOnly = false 
}) {
  const containerRef = useRef(null);
  const canvasRef = useRef(null);
  const overlayCanvasRef = useRef(null);
  
  const [zoom, setZoom] = useState(0.6);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [selectStart, setSelectStart] = useState(null);
  const [currentSelection, setCurrentSelection] = useState(null);
  const [hoveredPixel, setHoveredPixel] = useState(null);

  // Create pixel lookup map for efficient rendering
  const pixelMap = useRef(new Map());
  
  useEffect(() => {
    pixelMap.current.clear();
    pixels.forEach(pixel => {
      pixelMap.current.set(`${pixel.x},${pixel.y}`, pixel);
    });
  }, [pixels]);

  // Draw main grid
  const drawGrid = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const pixelSize = zoom;
    
    // Clear canvas
    ctx.fillStyle = '#fafaf9';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw grid lines (at certain zoom levels)
    if (zoom >= 2) {
      ctx.strokeStyle = 'rgba(0,0,0,0.05)';
      ctx.lineWidth = 0.5;
      
      const startX = Math.max(0, Math.floor(-offset.x / pixelSize));
      const startY = Math.max(0, Math.floor(-offset.y / pixelSize));
      const endX = Math.min(GRID_SIZE, Math.ceil((canvas.width - offset.x) / pixelSize));
      const endY = Math.min(GRID_SIZE, Math.ceil((canvas.height - offset.y) / pixelSize));

      for (let x = startX; x <= endX; x++) {
        const screenX = x * pixelSize + offset.x;
        ctx.beginPath();
        ctx.moveTo(screenX, 0);
        ctx.lineTo(screenX, canvas.height);
        ctx.stroke();
      }
      
      for (let y = startY; y <= endY; y++) {
        const screenY = y * pixelSize + offset.y;
        ctx.beginPath();
        ctx.moveTo(0, screenY);
        ctx.lineTo(canvas.width, screenY);
        ctx.stroke();
      }
    }

    // Draw sold pixels
    pixels.forEach(pixel => {
      const screenX = pixel.x * pixelSize + offset.x;
      const screenY = pixel.y * pixelSize + offset.y;
      
      // Only draw if visible
      if (screenX + pixelSize < 0 || screenX > canvas.width ||
          screenY + pixelSize < 0 || screenY > canvas.height) {
        return;
      }

      // Random color based on order_id for demo (in real app, use image)
      const hash = pixel.order_id.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0);
      const hue = Math.abs(hash) % 360;
      ctx.fillStyle = `hsl(${hue}, 70%, 60%)`;
      ctx.fillRect(screenX, screenY, pixelSize, pixelSize);
    });

    // Draw grid boundary
    ctx.strokeStyle = 'rgba(0,0,0,0.2)';
    ctx.lineWidth = 2;
    ctx.strokeRect(offset.x, offset.y, GRID_SIZE * pixelSize, GRID_SIZE * pixelSize);
  }, [zoom, offset, pixels]);

  // Draw selection overlay
  const drawOverlay = useCallback(() => {
    const canvas = overlayCanvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const pixelSize = zoom;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw current selection
    const sel = currentSelection || selection;
    if (sel) {
      const screenX = sel.startX * pixelSize + offset.x;
      const screenY = sel.startY * pixelSize + offset.y;
      const screenWidth = sel.width * pixelSize;
      const screenHeight = sel.height * pixelSize;

      ctx.fillStyle = 'rgba(240, 147, 50, 0.3)';
      ctx.fillRect(screenX, screenY, screenWidth, screenHeight);
      
      ctx.strokeStyle = '#f09332';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
      ctx.strokeRect(screenX, screenY, screenWidth, screenHeight);
      ctx.setLineDash([]);
    }

    // Draw hover highlight
    if (hoveredPixel && !readOnly) {
      const screenX = hoveredPixel.x * pixelSize + offset.x;
      const screenY = hoveredPixel.y * pixelSize + offset.y;
      
      ctx.strokeStyle = 'rgba(240, 147, 50, 0.8)';
      ctx.lineWidth = 2;
      ctx.strokeRect(screenX - 1, screenY - 1, pixelSize + 2, pixelSize + 2);
    }
  }, [zoom, offset, currentSelection, selection, hoveredPixel, readOnly]);

  // Handle canvas resize
  useEffect(() => {
    const updateSize = () => {
      const container = containerRef.current;
      const canvas = canvasRef.current;
      const overlay = overlayCanvasRef.current;
      
      if (container && canvas && overlay) {
        const rect = container.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
        overlay.width = rect.width;
        overlay.height = rect.height;
        
        // Center the grid initially
        if (offset.x === 0 && offset.y === 0) {
          setOffset({
            x: (rect.width - GRID_SIZE * zoom) / 2,
            y: (rect.height - GRID_SIZE * zoom) / 2
          });
        }
      }
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  // Redraw on changes
  useEffect(() => {
    drawGrid();
    drawOverlay();
  }, [drawGrid, drawOverlay]);

  // Convert screen coordinates to grid coordinates
  const screenToGrid = useCallback((screenX, screenY) => {
    const pixelSize = zoom;
    const gridX = Math.floor((screenX - offset.x) / pixelSize);
    const gridY = Math.floor((screenY - offset.y) / pixelSize);
    return {
      x: Math.max(0, Math.min(GRID_SIZE - 1, gridX)),
      y: Math.max(0, Math.min(GRID_SIZE - 1, gridY))
    };
  }, [zoom, offset]);

  // Mouse event handlers
  const handleMouseDown = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (e.button === 1 || e.button === 2 || e.altKey) {
      // Middle click or right click or alt+click: start panning
      setIsDragging(true);
      setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
    } else if (!readOnly && isSelecting) {
      // Left click: start selection
      const gridPos = screenToGrid(x, y);
      setSelectStart(gridPos);
      setCurrentSelection({
        startX: gridPos.x,
        startY: gridPos.y,
        width: 1,
        height: 1
      });
    } else if (!readOnly) {
      // Panning by default when not selecting
      setIsDragging(true);
      setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y });
    }
  };

  const handleMouseMove = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (isDragging) {
      setOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    } else if (selectStart) {
      const gridPos = screenToGrid(x, y);
      const startX = Math.min(selectStart.x, gridPos.x);
      const startY = Math.min(selectStart.y, gridPos.y);
      const endX = Math.max(selectStart.x, gridPos.x);
      const endY = Math.max(selectStart.y, gridPos.y);
      
      setCurrentSelection({
        startX,
        startY,
        width: endX - startX + 1,
        height: endY - startY + 1
      });
    } else {
      // Update hover position
      const gridPos = screenToGrid(x, y);
      setHoveredPixel(gridPos);
    }
  };

  const handleMouseUp = () => {
    if (selectStart && currentSelection && onSelect) {
      onSelect(currentSelection);
    }
    setIsDragging(false);
    setSelectStart(null);
    setCurrentSelection(null);
  };

  const handleMouseLeave = () => {
    setHoveredPixel(null);
    if (isDragging) {
      setIsDragging(false);
    }
  };

  const handleWheel = (e) => {
    e.preventDefault();
    const rect = canvasRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    const newZoom = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoom * zoomFactor));

    // Zoom towards mouse position
    const scale = newZoom / zoom;
    setOffset({
      x: mouseX - (mouseX - offset.x) * scale,
      y: mouseY - (mouseY - offset.y) * scale
    });
    setZoom(newZoom);
  };

  const handleZoomIn = () => {
    const newZoom = Math.min(MAX_ZOOM, zoom * 1.5);
    const canvas = canvasRef.current;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const scale = newZoom / zoom;
    setOffset({
      x: centerX - (centerX - offset.x) * scale,
      y: centerY - (centerY - offset.y) * scale
    });
    setZoom(newZoom);
  };

  const handleZoomOut = () => {
    const newZoom = Math.max(MIN_ZOOM, zoom / 1.5);
    const canvas = canvasRef.current;
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const scale = newZoom / zoom;
    setOffset({
      x: centerX - (centerX - offset.x) * scale,
      y: centerY - (centerY - offset.y) * scale
    });
    setZoom(newZoom);
  };

  const handleReset = () => {
    const canvas = canvasRef.current;
    const newZoom = 0.6;
    setZoom(newZoom);
    setOffset({
      x: (canvas.width - GRID_SIZE * newZoom) / 2,
      y: (canvas.height - GRID_SIZE * newZoom) / 2
    });
  };

  return (
    <div 
      ref={containerRef}
      className="pixel-grid-container w-full h-full min-h-[400px] relative bg-stone-100 dark:bg-stone-900"
      onContextMenu={e => e.preventDefault()}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0"
      />
      <canvas
        ref={overlayCanvasRef}
        className="absolute inset-0 cursor-crosshair"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onWheel={handleWheel}
        style={{ cursor: isDragging ? 'grabbing' : (isSelecting ? 'crosshair' : 'grab') }}
      />
      
      {/* Zoom controls */}
      <div className="zoom-controls">
        <button onClick={handleZoomIn} className="zoom-btn" title="Zoom In">+</button>
        <button onClick={handleZoomOut} className="zoom-btn" title="Zoom Out">−</button>
        <button onClick={handleReset} className="zoom-btn text-sm" title="Reset View">⟲</button>
      </div>

      {/* Info overlay */}
      <div className="absolute top-4 left-4 bg-white/90 dark:bg-stone-900/90 backdrop-blur px-3 py-2 rounded-lg text-sm font-mono">
        <span className="text-stone-500">Zoom:</span> {(zoom * 100).toFixed(0)}%
        {hoveredPixel && (
          <span className="ml-3">
            <span className="text-stone-500">Pos:</span> ({hoveredPixel.x}, {hoveredPixel.y})
          </span>
        )}
      </div>

      {/* Selection info */}
      {(currentSelection || selection) && (
        <div className="absolute top-4 right-4 bg-primary-500 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-lg">
          {(currentSelection || selection).width} × {(currentSelection || selection).height} = {' '}
          {(currentSelection || selection).width * (currentSelection || selection).height} pixels
        </div>
      )}
    </div>
  );
}
