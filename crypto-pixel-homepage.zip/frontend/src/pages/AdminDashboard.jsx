import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { formatCurrency, formatNumber } from '../utils/api';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { authFetch, logout, user } = useAuth();
  const [stats, setStats] = useState(null);
  const [orders, setOrders] = useState([]);
  const [wallets, setWallets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('orders');
  const [statusFilter, setStatusFilter] = useState('');
  const [editingWallet, setEditingWallet] = useState(null);

  useEffect(() => {
    loadData();
  }, [statusFilter]);

  const loadData = async () => {
    try {
      const [statsRes, ordersRes, walletsRes] = await Promise.all([
        authFetch('/api/admin/stats'),
        authFetch(`/api/admin/orders${statusFilter ? `?status=${statusFilter}` : ''}`),
        authFetch('/api/admin/wallets')
      ]);

      if (statsRes.ok) setStats(await statsRes.json());
      if (ordersRes.ok) setOrders((await ordersRes.json()).orders);
      if (walletsRes.ok) setWallets((await walletsRes.json()).wallets);
    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      const res = await authFetch(`/api/admin/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });

      if (res.ok) {
        loadData();
      }
    } catch (err) {
      console.error('Failed to update order:', err);
    }
  };

  const handleWalletUpdate = async (currency) => {
    const wallet = wallets.find(w => w.currency === currency);
    if (!wallet) return;

    try {
      const res = await authFetch(`/api/admin/wallets/${currency}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          address: wallet.address,
          network: wallet.network 
        })
      });

      if (res.ok) {
        setEditingWallet(null);
        loadData();
      }
    } catch (err) {
      console.error('Failed to update wallet:', err);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/admin');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-100 dark:bg-stone-950">
      {/* Header */}
      <header className="bg-white dark:bg-stone-900 border-b border-stone-200 dark:border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white font-bold">
                  $
                </div>
                <span className="font-display font-bold">Admin</span>
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-stone-500">Welcome, {user?.username}</span>
              <button onClick={handleLogout} className="btn-secondary text-sm py-2">
                Logout
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Grid */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="stat-card">
              <div className="stat-value">{formatCurrency(stats.totalRevenue)}</div>
              <div className="stat-label">Total Revenue</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{formatNumber(stats.totalPixelsSold)}</div>
              <div className="stat-label">Pixels Sold</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{stats.confirmedOrders}</div>
              <div className="stat-label">Confirmed Orders</div>
            </div>
            <div className="stat-card">
              <div className="stat-value text-amber-500">{stats.pendingOrders}</div>
              <div className="stat-label">Pending Orders</div>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {['orders', 'wallets'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors capitalize ${
                activeTab === tab 
                  ? 'bg-primary-500 text-white' 
                  : 'bg-white dark:bg-stone-800 hover:bg-stone-50 dark:hover:bg-stone-700'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Orders Tab */}
        {activeTab === 'orders' && (
          <div className="card p-0 overflow-hidden">
            <div className="p-4 border-b border-stone-200 dark:border-stone-700 flex items-center justify-between">
              <h2 className="font-bold">Orders</h2>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="input-field w-auto py-2"
              >
                <option value="">All Status</option>
                <option value="pending">Pending</option>
                <option value="confirmed">Confirmed</option>
                <option value="cancelled">Cancelled</option>
                <option value="refunded">Refunded</option>
              </select>
            </div>

            <div className="overflow-x-auto">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Email</th>
                    <th>Pixels</th>
                    <th>Amount</th>
                    <th>Crypto</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map(order => (
                    <tr key={order.id}>
                      <td className="font-mono text-xs">{order.id.slice(0, 8)}...</td>
                      <td>{order.email}</td>
                      <td>{order.pixel_count.toLocaleString()}</td>
                      <td className="font-bold">{formatCurrency(order.amount_usd)}</td>
                      <td>{order.crypto_currency}</td>
                      <td>
                        <span className={`badge ${order.status}`}>{order.status}</span>
                      </td>
                      <td className="text-sm text-stone-500">
                        {new Date(order.created_at).toLocaleDateString()}
                      </td>
                      <td>
                        <select
                          value={order.status}
                          onChange={(e) => handleStatusChange(order.id, e.target.value)}
                          className="text-sm border rounded px-2 py-1 bg-transparent"
                        >
                          <option value="pending">Pending</option>
                          <option value="confirmed">Confirm</option>
                          <option value="cancelled">Cancel</option>
                          <option value="refunded">Refund</option>
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {orders.length === 0 && (
                <div className="text-center py-12 text-stone-500">
                  No orders found
                </div>
              )}
            </div>
          </div>
        )}

        {/* Wallets Tab */}
        {activeTab === 'wallets' && (
          <div className="card">
            <h2 className="font-bold mb-6">Wallet Addresses</h2>
            <div className="space-y-4">
              {wallets.map(wallet => (
                <div key={wallet.currency} className="p-4 bg-stone-50 dark:bg-stone-800 rounded-xl">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl font-bold">{wallet.currency}</span>
                      <span className="text-sm text-stone-500">{wallet.network}</span>
                    </div>
                    <button
                      onClick={() => setEditingWallet(editingWallet === wallet.currency ? null : wallet.currency)}
                      className="text-sm text-primary-600 hover:underline"
                    >
                      {editingWallet === wallet.currency ? 'Cancel' : 'Edit'}
                    </button>
                  </div>
                  
                  {editingWallet === wallet.currency ? (
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={wallet.address}
                        onChange={(e) => {
                          const updated = wallets.map(w => 
                            w.currency === wallet.currency 
                              ? { ...w, address: e.target.value }
                              : w
                          );
                          setWallets(updated);
                        }}
                        className="input-field font-mono text-sm"
                        placeholder="Wallet address"
                      />
                      <input
                        type="text"
                        value={wallet.network || ''}
                        onChange={(e) => {
                          const updated = wallets.map(w => 
                            w.currency === wallet.currency 
                              ? { ...w, network: e.target.value }
                              : w
                          );
                          setWallets(updated);
                        }}
                        className="input-field text-sm"
                        placeholder="Network (e.g., ERC-20)"
                      />
                      <button
                        onClick={() => handleWalletUpdate(wallet.currency)}
                        className="btn-primary text-sm py-2"
                      >
                        Save Changes
                      </button>
                    </div>
                  ) : (
                    <code className="text-sm break-all text-stone-600 dark:text-stone-400">
                      {wallet.address}
                    </code>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
