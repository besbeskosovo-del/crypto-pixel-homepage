import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { fetchOrder, formatCurrency, getCryptoColor } from '../utils/api';

export default function OrderPage() {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const loadOrder = async () => {
      try {
        const data = await fetchOrder(orderId);
        setOrder(data.order);
      } catch (err) {
        setError('Order not found');
      } finally {
        setLoading(false);
      }
    };
    loadOrder();

    // Poll for updates every 30 seconds
    const interval = setInterval(loadOrder, 30000);
    return () => clearInterval(interval);
  }, [orderId]);

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(order.wallet_address);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400';
      case 'pending': return 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400';
      case 'cancelled': return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400';
      case 'refunded': return 'bg-stone-100 text-stone-800 dark:bg-stone-700 dark:text-stone-300';
      default: return 'bg-stone-100 text-stone-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner" />
      </div>
    );
  }

  if (error || !order) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="card text-center max-w-md">
          <div className="text-6xl mb-4">🔍</div>
          <h1 className="text-2xl font-bold mb-2">Order Not Found</h1>
          <p className="text-stone-500 mb-6">
            We couldn't find an order with ID: {orderId}
          </p>
          <Link to="/" className="btn-primary">
            Go Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-950 py-12">
      <div className="max-w-2xl mx-auto px-4">
        {/* Status Header */}
        <div className="card mb-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-display font-bold">Order Status</h1>
            <span className={`px-4 py-2 rounded-full text-sm font-medium capitalize ${getStatusColor(order.status)}`}>
              {order.status}
            </span>
          </div>

          <div className="font-mono text-sm text-stone-500 break-all">
            Order ID: {order.id}
          </div>
        </div>

        {/* Status-specific content */}
        {order.status === 'pending' && (
          <div className="card mb-6">
            <h2 className="text-xl font-bold mb-4 text-center">Complete Your Payment</h2>
            
            {/* Amount */}
            <div className="text-center mb-6">
              <p className="text-stone-500 text-sm">Amount to Pay</p>
              <p className="text-4xl font-display font-bold text-primary-600 dark:text-primary-400">
                {formatCurrency(order.amount_usd)}
              </p>
              <p className="text-sm text-stone-500">in {order.crypto_currency}</p>
            </div>

            {/* QR Code */}
            <div className="flex justify-center mb-6">
              <div className="p-4 bg-white rounded-xl shadow-inner">
                <QRCodeSVG 
                  value={order.wallet_address} 
                  size={180}
                  level="H"
                  fgColor={getCryptoColor(order.crypto_currency)}
                />
              </div>
            </div>

            {/* Wallet Address */}
            <div className="mb-4">
              <label className="block text-sm text-stone-500 mb-2">
                Send {order.crypto_currency} to this address
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={order.wallet_address}
                  className="input-field font-mono text-sm flex-1"
                />
                <button
                  onClick={copyAddress}
                  className={`px-4 py-2 rounded-xl font-medium transition-all ${
                    copied 
                      ? 'bg-emerald-500 text-white' 
                      : 'bg-stone-200 dark:bg-stone-700 hover:bg-stone-300 dark:hover:bg-stone-600'
                  }`}
                >
                  {copied ? '✓' : 'Copy'}
                </button>
              </div>
            </div>

            <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-xl p-4 text-sm">
              <p className="text-amber-800 dark:text-amber-200">
                ⏳ Your pixels are reserved for 30 minutes. Payment typically confirms within 10-60 minutes.
              </p>
            </div>
          </div>
        )}

        {order.status === 'confirmed' && (
          <div className="card mb-6 text-center">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-xl font-bold mb-2 text-emerald-600 dark:text-emerald-400">
              Payment Confirmed!
            </h2>
            <p className="text-stone-500">
              Your pixels are now live on the grid.
            </p>
            {order.tx_hash && (
              <p className="mt-4 font-mono text-xs text-stone-400 break-all">
                TX: {order.tx_hash}
              </p>
            )}
          </div>
        )}

        {order.status === 'cancelled' && (
          <div className="card mb-6 text-center">
            <div className="text-6xl mb-4">❌</div>
            <h2 className="text-xl font-bold mb-2 text-red-600 dark:text-red-400">
              Order Cancelled
            </h2>
            <p className="text-stone-500">
              This order has been cancelled. The pixels have been released.
            </p>
          </div>
        )}

        {/* Order Details */}
        <div className="card">
          <h3 className="font-bold mb-4">Order Details</h3>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-stone-500">Email</span>
              <p className="font-medium">{order.email}</p>
            </div>
            <div>
              <span className="text-stone-500">Pixels</span>
              <p className="font-medium">{order.pixel_count.toLocaleString()}</p>
            </div>
            <div>
              <span className="text-stone-500">Position</span>
              <p className="font-mono">({order.start_x}, {order.start_y})</p>
            </div>
            <div>
              <span className="text-stone-500">Size</span>
              <p className="font-mono">{order.width} × {order.height}</p>
            </div>
            <div>
              <span className="text-stone-500">Amount</span>
              <p className="font-bold text-primary-600">{formatCurrency(order.amount_usd)}</p>
            </div>
            <div>
              <span className="text-stone-500">Payment</span>
              <p className="font-medium">{order.crypto_currency}</p>
            </div>
            {order.website_url && (
              <div className="col-span-2">
                <span className="text-stone-500">Website</span>
                <p className="font-medium truncate">
                  <a href={order.website_url} target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:underline">
                    {order.website_url}
                  </a>
                </p>
              </div>
            )}
            <div className="col-span-2">
              <span className="text-stone-500">Created</span>
              <p className="font-medium">{new Date(order.created_at).toLocaleString()}</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex gap-4">
          <Link to="/" className="btn-secondary flex-1 text-center">
            Back to Home
          </Link>
          <Link to="/buy" className="btn-primary flex-1 text-center">
            Buy More Pixels
          </Link>
        </div>
      </div>
    </div>
  );
}
