import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import PixelGrid from '../components/PixelGrid';
import StatsDisplay from '../components/StatsDisplay';
import { fetchPixels, fetchStats } from '../utils/api';

export default function HomePage() {
  const [pixels, setPixels] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [pixelData, statsData] = await Promise.all([
          fetchPixels(),
          fetchStats()
        ]);
        setPixels(pixelData.pixels || []);
        setStats(statsData);
      } catch (err) {
        console.error('Failed to load data:', err);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-amber-50 dark:from-stone-950 dark:via-stone-900 dark:to-stone-950" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary-400/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-400/10 rounded-full blur-3xl" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 rounded-full text-sm font-medium mb-6">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary-500"></span>
              </span>
              Now accepting BTC, ETH, USDT, USDC
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold mb-6 leading-tight">
              Own a Piece of{' '}
              <span className="bg-gradient-to-r from-primary-500 to-amber-500 bg-clip-text text-transparent">
                Crypto History
              </span>
            </h1>
            
            <p className="text-lg text-stone-600 dark:text-stone-400 mb-8 max-w-2xl mx-auto">
              1 million pixels. $1 each. Pay with crypto. Your ad, logo, or artwork 
              immortalized on the blockchain-era's most iconic billboard.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/buy" className="btn-primary text-lg px-8 py-4">
                Buy Pixels Now
              </Link>
              <a href="#grid" className="btn-secondary text-lg px-8 py-4">
                Explore Grid
              </a>
            </div>
          </div>

          {/* Stats */}
          {stats && <StatsDisplay stats={stats} />}
        </div>
      </section>

      {/* Grid Section */}
      <section id="grid" className="py-16 bg-white dark:bg-stone-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-display font-bold mb-4">The Grid</h2>
            <p className="text-stone-500 dark:text-stone-400">
              Click and drag to explore. Each colored block represents sold pixels.
            </p>
          </div>
          
          <div className="h-[600px] rounded-2xl overflow-hidden shadow-2xl border border-stone-200 dark:border-stone-800">
            {loading ? (
              <div className="h-full flex items-center justify-center bg-stone-100 dark:bg-stone-800">
                <div className="spinner" />
              </div>
            ) : (
              <PixelGrid pixels={pixels} readOnly />
            )}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-stone-50 dark:bg-stone-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-display font-bold text-center mb-12">How It Works</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Select Pixels',
                description: 'Choose your spot on the 1000×1000 grid. Minimum 10×10 pixels ($100), maximum 50,000 pixels ($50,000).',
                icon: '🎯'
              },
              {
                step: '02',
                title: 'Upload & Pay',
                description: 'Upload your image and pay with BTC, ETH, USDT, or USDC. Scan the QR code or copy the wallet address.',
                icon: '💳'
              },
              {
                step: '03',
                title: 'Go Live',
                description: 'Once payment confirms, your pixels go live. Your image links to your website forever.',
                icon: '🚀'
              }
            ].map((item, index) => (
              <div key={index} className="card relative">
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-gradient-to-br from-primary-400 to-primary-600 rounded-xl flex items-center justify-center text-white font-bold font-mono shadow-lg">
                  {item.step}
                </div>
                <div className="text-4xl mb-4 mt-4">{item.icon}</div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-stone-500 dark:text-stone-400">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-primary-500 to-amber-500">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-display font-bold text-white mb-6">
            Ready to Claim Your Pixels?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Join hundreds of crypto projects, artists, and visionaries on the homepage that never forgets.
          </p>
          <Link to="/buy" className="inline-block bg-white text-primary-600 font-bold px-8 py-4 rounded-xl text-lg hover:bg-stone-100 transition-colors shadow-lg">
            Buy Pixels Now
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-stone-100 dark:bg-stone-900 border-t border-stone-200 dark:border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-sm text-stone-500">
              © 2024 Million Dollar Crypto Homepage. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <Link to="/admin" className="text-sm text-stone-500 hover:text-primary-600 transition-colors">
                Admin
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
