import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import PixelGrid from '../components/PixelGrid';
import CryptoSelector from '../components/CryptoSelector';
import PaymentModal from '../components/PaymentModal';
import { fetchPixels, fetchWallets, fetchSettings, checkAvailability, createOrder, formatCurrency } from '../utils/api';

export default function BuyPage() {
  const navigate = useNavigate();
  const [pixels, setPixels] = useState([]);
  const [wallets, setWallets] = useState([]);
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Selection state
  const [selection, setSelection] = useState(null);
  const [selectionValid, setSelectionValid] = useState(false);
  const [selectionError, setSelectionError] = useState(null);
  
  // Form state
  const [step, setStep] = useState(1);
  const [email, setEmail] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [selectedCrypto, setSelectedCrypto] = useState(null);
  
  // Order state
  const [submitting, setSubmitting] = useState(false);
  const [order, setOrder] = useState(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [pixelData, walletData, settingsData] = await Promise.all([
          fetchPixels(),
          fetchWallets(),
          fetchSettings()
        ]);
        setPixels(pixelData.pixels || []);
        setWallets(walletData.wallets || []);
        setSettings(settingsData);
      } catch (err) {
        console.error('Failed to load data:', err);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  // Validate selection
  useEffect(() => {
    if (!selection || !settings) {
      setSelectionValid(false);
      setSelectionError(null);
      return;
    }

    const validate = async () => {
      const pixelCount = selection.width * selection.height;
      
      if (pixelCount < settings.minPixels) {
        setSelectionValid(false);
        setSelectionError(`Minimum purchase is ${settings.minPixels} pixels (${Math.sqrt(settings.minPixels)}×${Math.sqrt(settings.minPixels)})`);
        return;
      }
      
      if (pixelCount > settings.maxPixels) {
        setSelectionValid(false);
        setSelectionError(`Maximum purchase is ${settings.maxPixels.toLocaleString()} pixels`);
        return;
      }

      try {
        const result = await checkAvailability(selection.startX, selection.startY, selection.width, selection.height);
        if (result.available) {
          setSelectionValid(true);
          setSelectionError(null);
        } else {
          setSelectionValid(false);
          setSelectionError('Some pixels in this area are already sold');
        }
      } catch (err) {
        setSelectionValid(false);
        setSelectionError('Failed to check availability');
      }
    };

    validate();
  }, [selection, settings]);

  const handleSelectionChange = (newSelection) => {
    setSelection(newSelection);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImage(file);
      const reader = new FileReader();
      reader.onload = (e) => setImagePreview(e.target.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!selection || !selectionValid || !email || !selectedCrypto) return;

    setSubmitting(true);
    try {
      const formData = new FormData();
      formData.append('email', email);
      formData.append('websiteUrl', websiteUrl);
      formData.append('startX', selection.startX);
      formData.append('startY', selection.startY);
      formData.append('width', selection.width);
      formData.append('height', selection.height);
      formData.append('cryptoCurrency', selectedCrypto);
      if (image) {
        formData.append('image', image);
      }

      const result = await createOrder(formData);
      
      if (result.success) {
        setOrder(result.order);
        setShowPaymentModal(true);
      } else {
        alert(result.error || 'Failed to create order');
      }
    } catch (err) {
      console.error('Order submission failed:', err);
      alert('Failed to submit order. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const pixelCount = selection ? selection.width * selection.height : 0;
  const totalPrice = pixelCount * (settings?.pricePerPixel || 1);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="spinner" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold mb-2">Buy Pixels</h1>
          <p className="text-stone-500 dark:text-stone-400">
            Select an area on the grid, upload your image, and pay with crypto.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Grid Section */}
          <div className="lg:col-span-2">
            <div className="card p-0 overflow-hidden">
              <div className="p-4 border-b border-stone-200 dark:border-stone-800">
                <h2 className="font-bold">Step 1: Select Your Pixels</h2>
                <p className="text-sm text-stone-500">Click and drag to select an area. Min {settings?.minPixels} pixels.</p>
              </div>
              <div className="h-[500px]">
                <PixelGrid 
                  pixels={pixels}
                  selection={selection}
                  onSelect={handleSelectionChange}
                  isSelecting={true}
                />
              </div>
            </div>

            {/* Selection info */}
            {selection && (
              <div className={`mt-4 p-4 rounded-xl ${selectionValid ? 'bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-800' : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800'}`}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">
                      Selected: {selection.width} × {selection.height} = {pixelCount.toLocaleString()} pixels
                    </p>
                    <p className="text-sm text-stone-500">
                      Position: ({selection.startX}, {selection.startY})
                    </p>
                    {selectionError && (
                      <p className="text-sm text-red-600 dark:text-red-400 mt-1">{selectionError}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                      {formatCurrency(totalPrice)}
                    </p>
                    <p className="text-sm text-stone-500">
                      ${settings?.pricePerPixel}/pixel
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Step 2: Details */}
            <div className="card">
              <h2 className="font-bold mb-4">Step 2: Your Details</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Email *</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="input-field"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Website URL</label>
                  <input
                    type="url"
                    value={websiteUrl}
                    onChange={(e) => setWebsiteUrl(e.target.value)}
                    placeholder="https://yoursite.com"
                    className="input-field"
                  />
                  <p className="text-xs text-stone-500 mt-1">Visitors will be linked to this URL</p>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1">Your Image</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                    id="image-upload"
                  />
                  <label
                    htmlFor="image-upload"
                    className="block border-2 border-dashed border-stone-300 dark:border-stone-700 rounded-xl p-4 text-center cursor-pointer hover:border-primary-500 transition-colors"
                  >
                    {imagePreview ? (
                      <img src={imagePreview} alt="Preview" className="max-h-32 mx-auto rounded" />
                    ) : (
                      <div className="text-stone-500">
                        <svg className="w-8 h-8 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <p className="text-sm">Click to upload image</p>
                      </div>
                    )}
                  </label>
                  {selection && (
                    <p className="text-xs text-stone-500 mt-1">
                      Recommended size: {selection.width} × {selection.height} pixels
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Step 3: Payment */}
            <div className="card">
              <h2 className="font-bold mb-4">Step 3: Select Payment Method</h2>
              <CryptoSelector 
                wallets={wallets}
                selected={selectedCrypto}
                onSelect={setSelectedCrypto}
              />
            </div>

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={!selectionValid || !email || !selectedCrypto || submitting}
              className="btn-primary w-full text-lg py-4 disabled:opacity-50"
            >
              {submitting ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="spinner w-5 h-5 border-white border-t-transparent" />
                  Processing...
                </span>
              ) : (
                `Pay ${formatCurrency(totalPrice)} with ${selectedCrypto || 'Crypto'}`
              )}
            </button>

            {/* Info */}
            <div className="text-sm text-stone-500 space-y-2">
              <p>• Pixels are reserved for 30 minutes while you pay</p>
              <p>• Your image goes live after payment confirmation</p>
              <p>• Keep your Order ID to track your purchase</p>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Modal */}
      {showPaymentModal && order && (
        <PaymentModal 
          order={order}
          onClose={() => {
            setShowPaymentModal(false);
            navigate(`/order/${order.id}`);
          }}
        />
      )}
    </div>
  );
}
