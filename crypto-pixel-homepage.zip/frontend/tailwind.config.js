/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fef7ee',
          100: '#fdedd3',
          200: '#f9d7a5',
          300: '#f5b96d',
          400: '#f09332',
          500: '#ec7612',
          600: '#dd5c08',
          700: '#b74309',
          800: '#92360f',
          900: '#762e10',
        },
        crypto: {
          btc: '#f7931a',
          eth: '#627eea',
          usdt: '#26a17b',
          usdc: '#2775ca',
        }
      },
      fontFamily: {
        display: ['Space Grotesk', 'system-ui', 'sans-serif'],
        body: ['DM Sans', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'float': 'float 6s ease-in-out infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        glow: {
          '0%': { boxShadow: '0 0 5px rgba(240, 147, 50, 0.5)' },
          '100%': { boxShadow: '0 0 20px rgba(240, 147, 50, 0.8)' },
        }
      }
    },
  },
  plugins: [],
}
